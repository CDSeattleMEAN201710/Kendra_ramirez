var express = require('express')
var session = require('express-session')
var app = express()
var path = require("path")
var bodyParser = require('body-parser');
var PORT = 8000

app.use(session({secret: 'codingdojorocks'}));  // string for encryption
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json({extended: true}));
app.set("views", path.join(__dirname, "./client/views"))
app.set("view engine", "ejs")
app.get("/", (req, res) =>{
  if (req.session && !req.session.number || !req.session.message) {
    req.session.number = Math.floor(Math.random()*(101 - 1) + 1)
    req.session.message = []
  }
  console.log(req.session.message, req.session.number);
  res.render("index", req.session)
})

app.post("/submit", (req, res) =>{
  if(req.session.message){
    req.session.message.pop()
  }
  if(req.body.num == req.session.number){
    req.session.message.push(req.session.number + ' was the number')
  }else if(req.body.num > req.session.number){
    req.session.message.push('Too High')
  }else{
    req.session.message.push('Too Low')
  }
  res.redirect("/")
  console.log("it worked!", req.body);
})
app.get("/reset", (req, res) =>{
  req.session.destroy()
  res.redirect("/")
})
app.listen(PORT, function(){
  console.log(`listening on port ${PORT}`)
})
